# Chrome Extension Setup Instructions

## Quick Start Guide

### Step 1: Install Dependencies

```bash
cd chrome-extension
npm install
```

### Step 2: Create Icons

Before building, you need to create icon files. The extension requires 4 icon sizes:

1. **Option A - Quick Placeholder**:
   - Create a simple 128x128 pixel green square (#00b894) with white text "TS"
   - Save it and resize to: 16x16, 32x32, 48x48, 128x128
   - Save them as `icons/icon16.png`, `icons/icon32.png`, `icons/icon48.png`, `icons/icon128.png`

2. **Option B - Use Online Tool**:
   - Go to https://favicon.io/favicon-generator/
   - Use text "TS" or upload a shield icon
   - Choose color #00b894
   - Download and extract all sizes to `icons/` folder

3. **Option C - Skip for Development**:
   - The extension will work without icons, but Chrome will show a default icon
   - You can add icons later

### Step 3: Build the Extension

```bash
npm run build
```

This creates a `dist` folder with all compiled files.

### Step 4: Load Extension in Chrome

1. Open Chrome and go to `chrome://extensions/`
2. **Enable Developer mode** (toggle in top-right)
3. Click **"Load unpacked"**
4. Navigate to and select the `chrome-extension/dist` folder
5. The extension should now appear in your extensions list

### Step 5: Start Backend Server

Make sure your Flask backend is running:

```bash
cd ..
python app.py
```

Backend should run on `http://localhost:5000`

### Step 6: Test the Extension

1. Click the ToxiScan icon in Chrome toolbar
2. Enter some text or upload an image
3. Click "Run Model"
4. View the results!

## Development Mode

For development with hot reload (note: Chrome extensions need to be rebuilt):

```bash
npm run dev
```

Then manually reload the extension in Chrome after each change, or use a watch script.

## Build Structure

After building, your `dist` folder should contain:

```
dist/
├── manifest.json
├── index.html
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── assets/
    ├── index-[hash].js
    ├── index-[hash].css
    └── ...
```

## Troubleshooting

### Build fails
- Make sure all dependencies are installed: `npm install`
- Check Node.js version (v16+ required)

### Extension won't load
- Ensure you're loading the `dist` folder, not the source
- Check that `manifest.json` exists in `dist/`
- Verify Developer mode is enabled

### Backend connection errors
- Check backend is running: `http://localhost:5000`
- Test backend in browser: `http://localhost:5000/api/health`
- Check CORS is enabled in Flask app

### Icons not showing
- Icons are optional for functionality
- Add icon files to `icons/` folder and rebuild

## Next Steps

- Customize colors in `src/styles/App.css`
- Add more features in React components
- Extend content script for page text analysis
- Add options page for settings

