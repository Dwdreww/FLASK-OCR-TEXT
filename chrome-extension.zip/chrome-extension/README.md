# ToxiScan Chrome Extension

A modern Chrome Extension for toxic comment detection with OCR capabilities, built with React and featuring a beautiful 3D neumorphic UI design.

## Features

- 🔍 **Text Analysis**: Analyze text comments for toxicity using AI
- 📷 **OCR Integration**: Extract text from images via drag-and-drop
- 🎨 **3D Modern UI**: Beautiful neumorphic/glassmorphism design
- 🚀 **Fast & Responsive**: Built with React and optimized for performance
- 🔗 **Backend Integration**: Connects to Flask backend API

## Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Chrome browser
- Flask backend server running on `http://localhost:5000`

## Installation & Setup

### 1. Install Dependencies

```bash
cd chrome-extension
npm install
```

### 2. Build the Extension

```bash
npm run build
```

This will create a `dist` folder with all the compiled extension files.

### 3. Load the Extension in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked**
4. Select the `dist` folder from the `chrome-extension` directory
5. The ToxiScan extension should now appear in your extensions list

### 4. Start the Backend Server

Make sure your Flask backend is running:

```bash
cd ../MLNLPSoftEng
python app.py
```

The backend should be running on `http://localhost:5000`

## Usage

1. Click the ToxiScan icon in your Chrome toolbar
2. Enter text in the text box OR upload an image via drag-and-drop
3. Click **Run Model** to analyze the text
4. View the toxicity prediction results with category breakdown

## Development

### Development Mode

```bash
npm run dev
```

### Build for Production

```bash
npm run build
```

## Project Structure

```
chrome-extension/
├── src/
│   ├── components/          # React components
│   │   ├── TextInput.jsx
│   │   ├── OCRUpload.jsx
│   │   └── PredictionResult.jsx
│   ├── styles/              # CSS styles
│   │   ├── index.css
│   │   └── App.css
│   ├── background/          # Service worker
│   │   └── background.js
│   ├── content/             # Content script
│   │   └── content.js
│   ├── App.jsx              # Main app component
│   └── main.jsx             # Entry point
├── icons/                   # Extension icons
├── public/                  # Static assets
├── manifest.json            # Extension manifest
├── index.html               # Popup HTML
├── vite.config.js           # Vite configuration
├── package.json             # Dependencies
└── README.md               # This file
```

## API Endpoints

The extension connects to the following backend endpoints:

- `POST /api/predict` - Analyze text for toxicity
- `POST /api/ocr` - Extract text from image

## Permissions

- `storage` - Store extension data
- `scripting` - Inject scripts if needed
- `activeTab` - Access current tab
- `host_permissions` - Connect to localhost:5000 backend

## Design

The extension features a modern 3D neumorphic design with:
- Primary color: Green (#00b894)
- Glassmorphism effects
- Smooth animations
- Responsive card-based layout
- React Tilt for 3D hover effects

## Troubleshooting

### Extension not loading
- Make sure you've built the extension first (`npm run build`)
- Check that you're loading the `dist` folder, not the source folder
- Ensure Developer mode is enabled in Chrome

### Backend connection errors
- Verify the Flask backend is running on `http://localhost:5000`
- Check that CORS is enabled in the Flask app
- Check browser console for detailed error messages

### OCR not working
- Ensure the backend OCR endpoint is working
- Check that the image format is supported (JPG, PNG, JPEG)
- Verify the backend has EasyOCR installed and configured

## License

MIT License

## Support

For issues or questions, please check the main project repository.

