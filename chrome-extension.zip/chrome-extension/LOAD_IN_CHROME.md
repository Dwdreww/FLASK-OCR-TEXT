# How to Load the Chrome Extension in Chrome

## Step-by-Step Instructions

### Step 1: Build the Extension
First, make sure you've built the extension:

```bash
cd chrome-extension
npm run build
```

This creates a `dist` folder with all the compiled files.

### Step 2: Open Chrome Extensions Page
1. Open Google Chrome browser
2. Type in the address bar: `chrome://extensions/`
   - Or go to: Menu (⋮) → Extensions → Manage Extensions

### Step 3: Enable Developer Mode
1. Look for a toggle switch in the **top-right corner** that says "Developer mode"
2. **Turn it ON** (it should be blue/highlighted)

### Step 4: Load the Extension
1. Click the **"Load unpacked"** button (appears after Developer mode is enabled)
2. Navigate to your extension folder:
   - Go to: `C:\Users\gigahertz\Documents\ASDASD\MLNLPSoftEng\chrome-extension`
   - Select the **`dist`** folder (NOT the chrome-extension folder itself)
   - Click "Select Folder" or "Select"

### Step 5: Verify Extension is Loaded
You should see:
- ✅ The ToxiScan extension appears in your extensions list
- ✅ An icon appears in your Chrome toolbar (top-right)
- ✅ You can see extension details, version, and toggle switch

### Step 6: Start Your Backend Server
Before using the extension, make sure your Flask backend is running:

```bash
cd C:\Users\gigahertz\Documents\ASDASD\MLNLPSoftEng
python app.py
```

The server should start on `http://localhost:5000`

### Step 7: Test the Extension
1. Click the **ToxiScan icon** in your Chrome toolbar
2. The popup should open with the text input and OCR upload
3. Enter some text and click "Run Model"
4. You should see the toxicity prediction results!

## Troubleshooting

### Extension doesn't appear after loading?
- Make sure you selected the **`dist`** folder, not the `chrome-extension` folder
- Check the Chrome Extensions page for error messages (red text)
- Make sure Developer mode is enabled

### "Manifest file is missing or unreadable" error?
- Run `npm run build` again
- Make sure the `dist` folder contains `manifest.json`

### Icons not showing?
- Extension works without icons, but you'll see a default Chrome icon
- See `ICONS_README.md` for instructions to add custom icons

### Backend connection errors?
- Make sure Flask server is running: `python app.py`
- Test backend in browser: `http://localhost:5000/api/health`
- Check that CORS is enabled in your Flask app

### "Failed to fetch" or connection errors?
- Check backend is running on `http://localhost:5000`
- Open browser console (F12) to see detailed error messages
- Make sure no firewall is blocking localhost connections

## After Making Changes

If you modify the extension code:
1. Rebuild: `npm run build`
2. Go to `chrome://extensions/`
3. Click the **refresh/reload icon** on the ToxiScan extension card
4. Test again!

## Removing the Extension

To remove the extension:
1. Go to `chrome://extensions/`
2. Find ToxiScan extension
3. Click "Remove"
4. Confirm removal

## Quick Reference

**Load Extension:**
1. `chrome://extensions/` → Enable Developer mode → Load unpacked → Select `dist` folder

**Start Backend:**
```bash
cd C:\Users\gigahertz\Documents\ASDASD\MLNLPSoftEng
python app.py
```

**Use Extension:**
- Click icon in toolbar → Enter text → Click "Run Model"

**Reload After Changes:**
- `npm run build` → Refresh extension in `chrome://extensions/`

