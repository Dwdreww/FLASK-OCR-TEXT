// Content Script for ToxiScan Extension
// This script runs in the context of web pages

console.log('ToxiScan content script loaded');

// Example: You can add functionality here to analyze text on the page
// For example, highlighting toxic comments, etc.

// Listen for messages from popup or background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPageText') {
    // Extract text from the page
    const pageText = document.body.innerText;
    sendResponse({ text: pageText });
  }
  return true;
});

