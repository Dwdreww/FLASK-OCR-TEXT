import React, { useState } from 'react';
import TextInput from './components/TextInput';
import OCRUpload from './components/OCRUpload';
import PredictionResult from './components/PredictionResult';
import './styles/App.css';

const API_BASE_URL = 'http://localhost:5000/api';

function App() {
  const [text, setText] = useState('');
  const [extractedText, setExtractedText] = useState('');
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleTextChange = (value) => {
    setText(value);
    setError(null);
    setPrediction(null);
  };

  const handleOCRResult = (ocrText) => {
    setExtractedText(ocrText);
    setText(ocrText);
    setError(null);
    setPrediction(null);
  };

  const handlePredict = async () => {
    const textToAnalyze = text.trim() || extractedText.trim();
    
    if (!textToAnalyze) {
      setError('Please enter text or upload an image first');
      return;
    }

    setLoading(true);
    setError(null);
    setPrediction(null);

    try {
      const response = await fetch(`${API_BASE_URL}/predict`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ comment: textToAnalyze }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }

      setPrediction(data);
    } catch (err) {
      console.error('Prediction error:', err);
      setError(err.message || 'Failed to analyze text. Make sure the backend server is running.');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setText('');
    setExtractedText('');
    setPrediction(null);
    setError(null);
  };

  return (
    <div className="app">
      <div className="app-header">
        <div className="logo">
          <span className="logo-icon">🛡️</span>
          <span className="logo-text">ToxiScan</span>
        </div>
      </div>

      <div className="app-content">
        <div className="tilt-card">
          <div className="card input-card">
            <h2 className="card-title">Text Analysis</h2>
            
            <TextInput
              value={text}
              onChange={handleTextChange}
              placeholder="Enter text to analyze for toxicity..."
            />

            <OCRUpload onTextExtracted={handleOCRResult} />

            {extractedText && (
              <div className="extracted-text-preview">
                <div className="extracted-label">Extracted Text:</div>
                <div className="extracted-content">{extractedText}</div>
              </div>
            )}

            <div className="card-actions">
              <button
                className="btn btn-secondary"
                onClick={handleClear}
                disabled={loading}
              >
                Clear
              </button>
              <button
                className="btn btn-primary"
                onClick={handlePredict}
                disabled={loading || (!text.trim() && !extractedText.trim())}
              >
                {loading ? 'Analyzing...' : 'Run Model'}
              </button>
            </div>

            {error && (
              <div className="error-message">
                <span className="error-icon">⚠️</span>
                {error}
              </div>
            )}
          </div>
        </div>

        {prediction && (
          <div className="tilt-card">
            <PredictionResult data={prediction} />
          </div>
        )}
      </div>
    </div>
  );
}

export default App;

