import React from 'react';

function PredictionResult({ data }) {
  const getSeverityClass = (severity) => {
    switch (severity) {
      case 'high':
        return 'severity-high';
      case 'medium':
        return 'severity-medium';
      case 'low':
        return 'severity-low';
      default:
        return 'severity-low';
    }
  };

  const getScoreColor = (score) => {
    const percentage = score * 100;
    if (percentage >= 60) return '#EF4444'; // Red
    if (percentage >= 30) return '#F59E0B'; // Yellow
    return '#10B981'; // Green
  };

  const scores = data.scores || {};
  const toxicScore = scores.toxic || 0;

  return (
    <div className="card result-card">
      <div className="card-header">
        <h2 className="card-title">Prediction Result</h2>
        <div className={`severity-badge ${getSeverityClass(data.severity)}`}>
          {data.emoji} {data.rating}
        </div>
      </div>

      <div className="result-content">
        <div className="overall-score">
          <div className="score-label">Overall Toxicity Score</div>
          <div className="score-value" style={{ color: getScoreColor(toxicScore) }}>
            {Math.round(toxicScore * 100)}%
          </div>
          <div className="score-bar">
            <div
              className="score-bar-fill"
              style={{
                width: `${toxicScore * 100}%`,
                backgroundColor: getScoreColor(toxicScore),
              }}
            ></div>
          </div>
        </div>

        <div className="category-scores">
          <h3 className="category-title">Category Breakdown</h3>
          <div className="categories-grid">
            {Object.entries(scores).map(([category, score]) => (
              <div key={category} className="category-item">
                <div className="category-label">
                  {category.replace(/_/g, ' ').toUpperCase()}
                </div>
                <div
                  className="category-value"
                  style={{ color: getScoreColor(score) }}
                >
                  {Math.round(score * 100)}%
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default PredictionResult;

