import React from 'react';

function TextInput({ value, onChange, placeholder }) {
  return (
    <div className="text-input-wrapper">
      <textarea
        className="text-input"
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows="6"
        autoFocus={false}
      />
      <div className="char-count">{(value || '').length} characters</div>
    </div>
  );
}

export default TextInput;

