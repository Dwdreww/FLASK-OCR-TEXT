// Background Service Worker for ToxiScan Extension

chrome.runtime.onInstalled.addListener(() => {
  console.log('ToxiScan Extension installed');
});

// Handle messages from content script or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'analyzeText') {
    // Handle text analysis request if needed
    console.log('Analysis request received:', request);
  }
  return true; // Keep message channel open for async response
});

// Keep service worker alive
chrome.runtime.onStartup.addListener(() => {
  console.log('ToxiScan Extension started');
});

