// Post-build script to copy manifest.json, icons, and other static files
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const distDir = path.join(__dirname, 'dist');

// Ensure dist directory exists
if (!fs.existsSync(distDir)) {
  console.error('dist directory not found! Run npm run build first.');
  process.exit(1);
}

// Check if icons exist in source directory first
const iconsSrc = path.join(__dirname, 'icons');
const iconFiles = ['icon16.png', 'icon32.png', 'icon48.png', 'icon128.png'];
const iconsExist = fs.existsSync(iconsSrc) && 
  iconFiles.every(icon => fs.existsSync(path.join(iconsSrc, icon)));

// Copy and modify manifest.json (remove icons if they don't exist)
const manifestSrc = path.join(__dirname, 'manifest.json');
const manifestDest = path.join(distDir, 'manifest.json');
if (fs.existsSync(manifestSrc)) {
  let manifestContent = fs.readFileSync(manifestSrc, 'utf8');
  const manifest = JSON.parse(manifestContent);
  
  if (!iconsExist) {
    // Remove icon references from manifest
    delete manifest.icons;
    if (manifest.action && manifest.action.default_icon) {
      delete manifest.action.default_icon;
    }
    console.log('⚠ Icons not found - removed icon references from manifest');
  }
  
  fs.writeFileSync(manifestDest, JSON.stringify(manifest, null, 2));
  console.log('✓ Copied and processed manifest.json');
} else {
  console.warn('⚠ manifest.json not found');
}

// Copy icons
const iconsDest = path.join(distDir, 'icons');
if (fs.existsSync(iconsSrc)) {
  if (!fs.existsSync(iconsDest)) {
    fs.mkdirSync(iconsDest, { recursive: true });
  }
  
  const iconFiles = ['icon16.png', 'icon32.png', 'icon48.png', 'icon128.png'];
  let copiedCount = 0;
  
  iconFiles.forEach(icon => {
    const srcPath = path.join(iconsSrc, icon);
    const destPath = path.join(iconsDest, icon);
    if (fs.existsSync(srcPath)) {
      fs.copyFileSync(srcPath, destPath);
      copiedCount++;
    }
  });
  
  if (copiedCount > 0) {
    console.log(`✓ Copied ${copiedCount} icon files`);
  } else {
    console.warn('⚠ No icon files found (extension will work but show default icon)');
  }
} else {
  console.warn('⚠ icons directory not found');
}

// Copy background and content scripts
const backgroundSrc = path.join(__dirname, 'src', 'background', 'background.js');
const backgroundDest = path.join(distDir, 'src', 'background', 'background.js');
if (fs.existsSync(backgroundSrc)) {
  const backgroundDestDir = path.dirname(backgroundDest);
  if (!fs.existsSync(backgroundDestDir)) {
    fs.mkdirSync(backgroundDestDir, { recursive: true });
  }
  fs.copyFileSync(backgroundSrc, backgroundDest);
  console.log('✓ Copied background.js');
}

const contentSrc = path.join(__dirname, 'src', 'content', 'content.js');
const contentDest = path.join(distDir, 'src', 'content', 'content.js');
if (fs.existsSync(contentSrc)) {
  const contentDestDir = path.dirname(contentDest);
  if (!fs.existsSync(contentDestDir)) {
    fs.mkdirSync(contentDestDir, { recursive: true });
  }
  fs.copyFileSync(contentSrc, contentDest);
  console.log('✓ Copied content.js');
}

console.log('\n✅ All files copied successfully!');
console.log('📦 Extension is ready in the dist/ folder');

