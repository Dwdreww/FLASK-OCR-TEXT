# Icon Setup

The extension requires icons in the following sizes:
- 16x16 pixels
- 32x32 pixels
- 48x48 pixels
- 128x128 pixels

## Creating Icons

You can create simple placeholder icons or design custom ones. Here's a quick way to create them:

### Option 1: Use an Online Tool
1. Go to a favicon generator like https://favicon.io/
2. Create an icon with a shield (🛡️) symbol or "TS" text
3. Use the primary green color (#00b894)
4. Download all sizes and place them in the `icons/` folder

### Option 2: Create Simple Icons with Image Editor
- Create a 128x128 image with a shield icon
- Use green (#00b894) background
- Resize to 16x16, 32x32, 48x48, 128x128
- Save as PNG files named:
  - `icon16.png`
  - `icon32.png`
  - `icon48.png`
  - `icon128.png`

### Option 3: Temporary Placeholder
For development, you can create simple colored squares:
1. Create a 128x128 green square (#00b894)
2. Add white text "TS" or shield emoji
3. Resize and save as above

Place all icon files in the `icons/` directory before building the extension.

